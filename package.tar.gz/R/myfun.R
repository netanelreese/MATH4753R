#' Quadratic Function
#'
#' @param x input vector
#'
#' @return squared vector valuse
#' @export
#'
#' @examples
#' myfun(1:4)
myfun <- function(x) {
  x*x
}
